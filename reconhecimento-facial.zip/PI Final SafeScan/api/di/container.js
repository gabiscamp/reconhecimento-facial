import FaceRecognitionService from '../services/faceRecognitionService.js';

const container = {
  faceRecognitionService: new FaceRecognitionService()
};

export default container;



