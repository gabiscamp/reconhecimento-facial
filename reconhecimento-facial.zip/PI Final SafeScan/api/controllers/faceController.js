
export const someFaceRecognitionHandler = (req, res) => {
  res.send("Reconhecimento facial realizado com sucesso");
};
